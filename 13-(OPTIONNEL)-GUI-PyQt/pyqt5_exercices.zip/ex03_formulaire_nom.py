import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton, QLineEdit

class Formulaire(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Exercice 3 – Formulaire simple")
        self.setGeometry(100, 100, 400, 200)

        self.label_nom = QLabel("Votre nom :", self)
        self.label_nom.move(50, 40)

        self.champ_nom = QLineEdit(self)
        self.champ_nom.move(150, 40)

        self.label_resultat = QLabel("", self)
        self.label_resultat.move(50, 130)

        self.btn_valider = QPushButton("Valider", self)
        self.btn_valider.move(150, 80)
        self.btn_valider.clicked.connect(self.afficher_nom)

    def afficher_nom(self):
        texte = self.champ_nom.text()
        if texte.strip():
            self.label_resultat.setText("Bonjour " + texte)
        else:
            self.label_resultat.setText("Veuillez entrer un nom.")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    fenetre = Formulaire()
    fenetre.show()
    sys.exit(app.exec_())