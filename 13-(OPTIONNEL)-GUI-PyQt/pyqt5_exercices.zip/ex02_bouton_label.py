import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel

class FenetreBouton(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Exercice 2 – Bouton et Label")
        self.setGeometry(100, 100, 400, 200)

        self.label = QLabel("Texte initial", self)
        self.label.move(150, 60)

        self.bouton = QPushButton("Changer le texte", self)
        self.bouton.move(130, 100)
        self.bouton.clicked.connect(self.changer_texte)

    def changer_texte(self):
        self.label.setText("Texte modifié !")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    fenetre = FenetreBouton()
    fenetre.show()
    sys.exit(app.exec_())