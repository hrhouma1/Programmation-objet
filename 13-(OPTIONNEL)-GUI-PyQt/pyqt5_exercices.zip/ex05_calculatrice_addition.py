import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton, QLineEdit

class Calculatrice(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Exercice 5 – Addition")
        self.setGeometry(100, 100, 400, 200)

        self.entree1 = QLineEdit(self)
        self.entree1.move(50, 30)

        self.entree2 = QLineEdit(self)
        self.entree2.move(200, 30)

        self.bouton = QPushButton("Calculer", self)
        self.bouton.move(150, 70)
        self.bouton.clicked.connect(self.calculer)

        self.resultat = QLabel("Résultat :", self)
        self.resultat.move(150, 120)

    def calculer(self):
        try:
            a = float(self.entree1.text())
            b = float(self.entree2.text())
            self.resultat.setText(f"Résultat : {a + b}")
        except ValueError:
            self.resultat.setText("Entrée invalide")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    fenetre = Calculatrice()
    fenetre.show()
    sys.exit(app.exec_())