import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton, QLineEdit, QTextEdit

class ContactForm(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Exercice 6 – Formulaire de contact")
        self.setGeometry(100, 100, 450, 300)

        QLabel("Nom :", self).move(30, 30)
        self.nom = QLineEdit(self)
        self.nom.move(100, 30)

        QLabel("Email :", self).move(30, 70)
        self.email = QLineEdit(self)
        self.email.move(100, 70)

        QLabel("Message :", self).move(30, 110)
        self.message = QTextEdit(self)
        self.message.setGeometry(100, 110, 300, 100)

        self.btn = QPushButton("Envoyer", self)
        self.btn.move(180, 230)
        self.btn.clicked.connect(self.envoyer)

        self.label_resultat = QLabel("", self)
        self.label_resultat.move(100, 260)

    def envoyer(self):
        if self.nom.text().strip() and self.email.text().strip():
            self.label_resultat.setText("Message envoyé.")
        else:
            self.label_resultat.setText("Veuillez remplir tous les champs obligatoires.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    fenetre = ContactForm()
    fenetre.show()
    sys.exit(app.exec_())